import time
import cv2
from tflite_runtime.interpreter import Interpreter
import re


class SSD:
    def __init__(self):
        self.labels = self.load_labels("model_data/labels.txt")
        self.interpreter = Interpreter("model_data/object_detetion_advantech.tflite")
        self.input_details = self.interpreter.get_input_details()
        self.output_details = self.interpreter.get_output_details()
        self.interpreter.allocate_tensors()
        _, self.img_inp_shape, _, _ = self.input_details[0]['shape']
        self.threshold = 0.5

    def load_labels(self,path):
        """Loads the labels file. Supports files with or without index numbers."""
        with open(path, 'r', encoding='utf-8') as f:
            lines = f.readlines()
            labels = {}
            for row_number, content in enumerate(lines):
                pair = re.split(r'[:\s]+', content.strip(), maxsplit=1)
                if len(pair) == 2 and pair[0].strip().isdigit():
                    labels[int(pair[0])] = pair[1].strip()
                else:
                    labels[row_number] = pair[0].strip()
        return labels

    def get_image(self):
        cam = cv2.VideoCapture(0)
        check, frame = cam.read()
        self.orig_width, self.orig_height, _ = frame.shape
        frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        frame = cv2.resize(frame, (self.img_inp_shape, self.img_inp_shape))
        return frame

    def detect(self):
        img = self.get_image()
        start_time = time.time()
        self.interpreter.set_tensor(self.input_details[0]['index'], [img])

        self.interpreter.invoke()
        rects = self.interpreter.get_tensor(self.output_details[0]['index'])
        classes = self.interpreter.get_tensor(self.output_details[1]['index'])
        scores = self.interpreter.get_tensor(self.output_details[2]['index'])
        img = cv2.cvtColor(img, cv2.COLOR_RGB2BGR)
        for index, score in enumerate(scores[0]):
            if score > self.threshold:
                print(self.labels[classes[0][index]])
                self.draw_rect(img, rects[0][index], self.labels[classes[0][index]])

        # cv2.imshow("detected", img)
        new_img = cv2.resize(img, (self.orig_height,self.orig_width))
        cv2.imshow("resized", new_img)
        print(time.time()-start_time)
        cv2.waitKey(0)

    def draw_rect(self, image, box, label):
        y_min = int(max(1, (box[0] * self.img_inp_shape)))
        x_min = int(max(1, (box[1] * self.img_inp_shape)))
        y_max = int(min(self.img_inp_shape, (box[2] * self.img_inp_shape)))
        x_max = int(min(self.img_inp_shape, (box[3] * self.img_inp_shape)))

        # draw a rectangle on the image
        cv2.rectangle(image, (x_min, y_min), (x_max, y_max), (0, 255, 0), 1)
        cv2.putText(image, label, (x_min, y_min),cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0,0,255))

ssd = SSD()
ssd.detect()
